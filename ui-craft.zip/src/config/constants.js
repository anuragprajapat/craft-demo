export const Constants = {
  BASE_COLOR: "#424db0",
  GREY: "grey",
  TAG: "#EAEEFD",
  BASE_URL: "http://localhost:4000/",
  ROUTES: {
    JOB: "job"
  }
};
